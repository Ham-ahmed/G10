#!/usr/bin/python
# -*- coding: utf-8 -*-

# ======================================================================
# MagicapanelGold Plugin
# ======================================================================

from __future__ import absolute_import
__author__ = "Magic"
__email__ = "magicpanelgold@gmail.com"
__copyright__ = 'Copyright (c) 2026 Magic'
__license__ = "GPL-v2"
__version__ = "1.0.0"

from Components.Language import language
from Tools.Directories import resolveFilename, SCOPE_PLUGINS
import gettext
import os


PluginLanguageDomain = 'MagicapanelGold'
PluginLanguagePath = 'Extensions/MagicapanelGold/locale'


isDreambox = False
if os.path.exists("/usr/bin/apt-get"):
    isDreambox = True


def localeInit():
    if isDreambox:
        lang = language.getLanguage()[:2]
        os.environ["LANGUAGE"] = lang
    gettext.bindtextdomain(PluginLanguageDomain, resolveFilename(SCOPE_PLUGINS, PluginLanguagePath))


if isDreambox:
    def _(txt):
        return gettext.dgettext(PluginLanguageDomain, txt) if txt else ""
else:
    def _(txt):
        translated = gettext.dgettext(PluginLanguageDomain, txt)
        if translated:
            return translated
        else:
            print(("[%s] fallback to default translation for %s" % (PluginLanguageDomain, txt)))
            return gettext.gettext(txt)

localeInit()
language.addCallback(localeInit)